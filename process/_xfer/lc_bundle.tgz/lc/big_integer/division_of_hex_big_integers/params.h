#pragma once
constexpr int T_MAX = 1600000;
constexpr long long LOG_16_A_AND_B_MAX = 1600000;
constexpr long long SUM_OF_CHARACTER_LENGTH = 3200002;
